# Общее
Код сделал на основе https://github.com/rappasoft/laravel-5-boilerplate).
# Установка

* В `composer.json` добавить:
```
"repositories": [
    {
        "type": "vcs",
        "url": "git@bitbucket.org:Dok5/lang-switcher.git"
    }
],

"require": {
    "dok5/lang-switcher": "*"
  },
  
```

* При необходимости:

Публикация config-файла:

`php artisan vendor:publish --provider="Dok5\LangSwitcher\LangSwitcherServiceProvider" --tag=config`


Публикация представления:

`php artisan vendor:publish --provider="Dok5\LangSwitcher\LangSwitcherServiceProvider" --tag=view`